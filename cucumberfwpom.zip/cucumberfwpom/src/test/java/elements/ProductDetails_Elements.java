package elements;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductDetails_Elements {
	WebDriver driver;
	@FindBy(xpath = "//*[@id='item2b6c57ce73']/div/div[2]/a/div/span") public WebElement productLink1;
	@FindBy(xpath = "//*[@id='x-msku__select-box-1000']/option") public List<WebElement> storageOptions;
	@FindBy(xpath = "//*[@id='x-msku__select-box-1001']/option") public List<WebElement> networkOptions;
	@FindBy(xpath = "//*[@id='x-msku__select-box-1002']/option") public List<WebElement> colorOptions;
	@FindBy(xpath = "//*[@id='qtyTextBox']") public WebElement quantityBox;
	@FindBy(xpath = "//a[@id='atcBtn_btn_1']") public WebElement addToCart;
	@FindBy(css = "#mainContent > div > div.vim.vi-evo-row-gap > ul > li:nth-child(2) > div.vim.x-atc-action.oldLayout.overlay-placeholder.atcv2modal > div > div.lightbox-dialog__window.lightbox-dialog__window--animate.keyboard-trap--active > div.lightbox-dialog__main > div > div") public WebElement overlayElement;
	@FindBy(xpath = "//span[contains(text(),'Go to cart')]") public WebElement goToCart;
	@FindBy(xpath = "//a[@href='https://www.ebay.com/itm/186501287539?var=694552847488']") public WebElement addedProduct;

	public ProductDetails_Elements(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
