package testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
	features = {"features"},
	glue = {"steps"},
	plugin = {"pretty", "json:target/cucumber-report/cucumber.json", "html:target/cucumber-html-report"},
	dryRun = false,
	//	monochrome = false,
	tags = "@AP2 or @H3"
	)
public class TestRunner {

}
