package actions;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import elements.ProductDetails_Elements;
import steps.Common_Steps;

public class EbayAddProductsToCart_Actions {

	private WebDriver driver;
	ProductDetails_Elements productdetails_elements;
//	public WebDriverWait webDriverWait;
//	final int WAIT_FOR_ELEMENT_TIMEOUT = 30;
	public EbayAddProductsToCart_Actions(Common_Steps common_steps) {
		this.driver = common_steps.getdriver();
		productdetails_elements = new ProductDetails_Elements(driver);
	}
	
	public void clickProductLink() {
		productdetails_elements.productLink1.click();
	}
	
	public void getAllOpenWindows() {
	Set<String> openWindows = driver.getWindowHandles();
	for (String window : openWindows) {
		driver.switchTo().window(window).getTitle().contains("Apple iPhone 11");
	}	
	}
	public void selectStorage(String option) {
		List<WebElement> storage = productdetails_elements.storageOptions;
		for(WebElement StorageCapacity: storage){
			if(StorageCapacity.getText().trim().toLowerCase().equals(option.trim().toLowerCase())) {
				StorageCapacity.click();
				break;
			}
		}
	}
	
	public void selectNetwork(String option) {
		List<WebElement> network = productdetails_elements.networkOptions;
		for(WebElement Network: network) {
			if(Network.getText().trim().toLowerCase().equals(option.trim().toLowerCase())) {
				Network.click();
				break;
			}
		}
	}
	
	public void selectColor(String option) {
		List<WebElement> color = productdetails_elements.colorOptions;
		for(WebElement Color: color) {
			if(Color.getText().trim().toLowerCase().equals(option.trim().toLowerCase())) {
				Color.click();
				break;
			}
		}
	}
	
	public void enterQuantityString(String string) {
		productdetails_elements.quantityBox.clear();
		productdetails_elements.quantityBox.sendKeys(string);
	}
	
	public void clickAddToCartBtn() throws Exception {
		productdetails_elements.addToCart.click();
	}
	
	//get the lightbox and wait for it to be fully loaded
	public WebElement getOverlayElement() {
		return productdetails_elements.overlayElement;
	}
	public void waitForOverlayelement() {
		WebDriverWait webDriverWait;
		final int WAIT_FOR_ELEMENT_TIMEOUT = 30;
		webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_ELEMENT_TIMEOUT));
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#mainContent > div > div.vim.vi-evo-row-gap > ul > li:nth-child(2) > div.vim.x-atc-action.oldLayout.overlay-placeholder.atcv2modal > div > div.lightbox-dialog__window.lightbox-dialog__window--animate.keyboard-trap--active > div.lightbox-dialog__main > div > div")));
	}

	public void clickGoToCartBtn() {
		productdetails_elements.goToCart.click();
	}
	public void getCartWindow() throws Exception {
	Set<String> openWindows = driver.getWindowHandles();
	for (String window : openWindows) {
		driver.switchTo().window(window).getCurrentUrl().contains("cart.ebay.com");
	}	
	Thread.sleep(2000);
	}
	
	public void viewAddedProduct() {
		WebElement linkElement = productdetails_elements.addedProduct;
		String productName = linkElement.getText();
		System.out.println("Product name is as expected " + productName);
	}
}
