package actions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import elements.EbayHome_Elements;
import steps.Common_Steps;

public class EbayHome_Actions {

//create object of elements
//create a constructor for this class, this constructor is going to use driver from common_steps
	EbayHome_Elements ebayhome_elements;
	private WebDriver driver;

	public EbayHome_Actions(Common_Steps common_steps) {
		this.driver = common_steps.getdriver();
		//invoke or instantiate elements factory into this page
		ebayhome_elements = new EbayHome_Elements(driver);
	}
		
	public void clickAdvancedLink() {
		ebayhome_elements.advancedLink.click();
	}
	
	public void enterSearchString(String string) {
		ebayhome_elements.searchBox.sendKeys(string);
	}
	
	public void clickSearchBtn() {
		ebayhome_elements.searchButton.click();
	}
	
	public int getSearchItemsCount() {
		String itemCount = ebayhome_elements.numOfItems.getText().trim();
		String itemCount2 = itemCount.replace(",", "");
		int itemCountInt = Integer.parseInt(itemCount2);
		return itemCountInt;
	}
	
	public void selectCategory(String option) {
		List<WebElement> cat = ebayhome_elements.catOptions;
		for(WebElement x: cat) {
			if(x.getText().trim().toLowerCase().equals(option.trim().toLowerCase())) {
				x.click();
				break;
			}
		}
	}
	
	public void clickonbreadcrumblink(String Text) {
		driver.findElement(By.linkText(Text)).click();
	}
}
