package steps;

import static org.junit.Assert.fail;

import actions.Common_Actions;
import actions.EbayAdvancedSearch_Actions;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EbayAdvancedSearch_Steps {
//declare the objects of actions at class level
Common_Actions common_actions;
EbayAdvancedSearch_Actions ebayadvancedsearch_actions;

//using picocontainer dependancy we can use driver in step definition class
//create constructor of this class where we pass the argument with object of common steps for this class
	public EbayAdvancedSearch_Steps(Common_Actions common_actions, EbayAdvancedSearch_Actions ebayadvancedsearch_actions) {
		//use constructor argument as the object of this class
		this.common_actions = common_actions;
		this.ebayadvancedsearch_actions = ebayadvancedsearch_actions;
	}

	@Given("I am on Ebay Advanced Search page")
	public void i_am_on_ebay_advanced_search_page(){
		common_actions.goToUrl("https://www.ebay.com/sch/ebayadvsearch");

	}
	@When("I click on Ebay logo")
	public void i_click_on_ebay_logo() {
		ebayadvancedsearch_actions.clickOnEbayLogo();

	}
	@Then("I am navigated to Ebay Home page")
	public void i_am_navigated_to_ebay_home_page() {
		String expUrl = "https://www.ebay.com/";
		String actUrl = common_actions.getCurrentPageUrl();
		if(!expUrl.equals(actUrl)) {
			fail("Page does not navigate to ebay Home page.");
		}
	}
	@When("I advanced search an item")
	public void i_advanced_search_an_item(DataTable dataTable) {
		ebayadvancedsearch_actions.enterSearchString(dataTable.cell(1,0));
		ebayadvancedsearch_actions.enterExcludeString(dataTable.cell(1,1));
		ebayadvancedsearch_actions.enterMinPrice(dataTable.cell(1,2));
		ebayadvancedsearch_actions.enterMaxPrice(dataTable.cell(1,3));
		ebayadvancedsearch_actions.clickOnSearchBtn();
	}

}
