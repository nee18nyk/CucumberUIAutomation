package steps;

import static org.junit.Assert.fail;

import actions.Common_Actions;
import actions.EbayAddProductsToCart_Actions;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EbayAddProductsToCart_Steps {
	
	Common_Actions common_actions;
	EbayAddProductsToCart_Actions ebayaddproductstocart_actions;
	public EbayAddProductsToCart_Steps(Common_Actions common_actions, EbayAddProductsToCart_Actions ebayaddproductstocart_actions) {
		this.common_actions = common_actions;
		this.ebayaddproductstocart_actions = ebayaddproductstocart_actions;
	}
	@When("I select a product")
	public void i_select_a_product() throws Exception {
		ebayaddproductstocart_actions.clickProductLink();
		Thread.sleep(2000);
		String actUrl = common_actions.getCurrentPageUrl();
		System.out.println("Page URL is " + actUrl);
	}

	@Then("I am navigated to product details page of a product")
	public void i_am_navigated_to_product_details_page_of_a_product(DataTable dataTable) throws Exception {
		ebayaddproductstocart_actions.getAllOpenWindows();
		String actTitle = common_actions.getCurrentPageTitle();
		if(!actTitle.contains(dataTable.cell(1,0))) {
			fail("Page is not displaying the expected product title " +(dataTable.cell(1,0)) +"but displays" + actTitle);
		}
		Thread.sleep(2000);
		System.out.println("Page title is " + actTitle);
	}

	@When("I provide product specifications")
	public void i_provide_product_specifications(DataTable dataTable) throws Exception {
		ebayaddproductstocart_actions.selectStorage(dataTable.cell(1,0));
		ebayaddproductstocart_actions.selectNetwork(dataTable.cell(1,1));
		ebayaddproductstocart_actions.selectColor(dataTable.cell(1,2));
		ebayaddproductstocart_actions.enterQuantityString(dataTable.cell(1,3));
	}

	@When("add to cart")
	public void add_to_cart() throws Exception {
		ebayaddproductstocart_actions.clickAddToCartBtn();
		ebayaddproductstocart_actions.getOverlayElement();
		ebayaddproductstocart_actions.waitForOverlayelement();
		Thread.sleep(2000);
	}

	@When("go to cart")
	public void go_to_cart() {
		ebayaddproductstocart_actions.clickGoToCartBtn();
	}

	@Then("I am navigated to the cart page")
	public void i_am_navigated_to_the_cart_page(DataTable dataTable) throws Exception {
		ebayaddproductstocart_actions.getCartWindow();
		String actTitle1 = common_actions.getCurrentPageTitle();
		if(!actTitle1.trim().toLowerCase().contains(dataTable.cell(1,0))) {
			fail("Page is not displaying the expected title " +(dataTable.cell(1,0)) +" but displays " + actTitle1);
		}
		Thread.sleep(1000);
		System.out.println("Page title is " + actTitle1);
	}

	@Then("the added product is correctly displayed")
	public void the_added_product_is_correctly_displayed() {
		ebayaddproductstocart_actions.viewAddedProduct();
	}



}