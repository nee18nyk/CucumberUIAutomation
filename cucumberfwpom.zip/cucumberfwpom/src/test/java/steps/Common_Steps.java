package steps;

import java.time.Duration;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Common_Steps {
	//restrict direct access of this driver with private
	private WebDriver driver;
	public WebDriverWait webDriverWait;
	final int WAIT_FOR_ELEMENT_TIMEOUT = 30;
	//setting and launching the instance of chrome driver
	@Before
	public void setUp() {
		//System.setProperty("webdriver.chrome.driver", "webdrivers/chromedriver");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_ELEMENT_TIMEOUT));
		System.out.println("Global before hook executed before each gherkin scenario");
	}

	//quit the driver
	@After
	public void tearDown(Scenario scenario) throws Exception {
		if(scenario.isFailed()) {
			//if scenario is passed it will not take screenshot, it takes only if failed
			final byte[] scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES); //selenium code takes screenshot inside scr as a byte
			scenario.attach(scr, "image/png", scenario.getName()); //then it will embed inside scenario object. it goes to default cucumber report, then from there it goes to masterthought report
		}
		driver.quit();
		Thread.sleep(1000); //takes breathing time to close driver while running back to back scenarios
		System.out.println("Global after hook executed after each gherkin scenario");
	}
	//create another method because we want to return driver, the webdriver we are creating as part of this class, we want to return it to some other class
	public WebDriver getdriver() {
		return driver;
	}
}
