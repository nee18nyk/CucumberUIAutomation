package steps;

import static org.junit.Assert.fail;

import actions.Common_Actions;
import actions.EbayHome_Actions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EbayHome_Steps {
	Common_Actions common_actions;
	EbayHome_Actions ebayhome_actions;
	public EbayHome_Steps(Common_Actions common_actions, EbayHome_Actions ebayhome_actions) {
		this.common_actions = common_actions;
		this.ebayhome_actions = ebayhome_actions;
	}
	@Given("I am on Ebay home page")
	public void i_am_on_ebay_home_page() { 
		common_actions.goToUrl("https://www.ebay.com/");
	}

	@When("I click on Advanced link")
	public void i_click_on_advanced_link() {
		ebayhome_actions.clickAdvancedLink();
	}

	@Then("I navigate to advanced search page")
	public void i_navigate_to_advanced_search_page() {
		String expUrl = "https://www.ebay.com/sch/ebayadvsearch";
		String actUrl = common_actions.getCurrentPageUrl();
		if(!expUrl.equals(actUrl)) {
			fail("Page does not navigate to advanced search page");
		}
	}
	
	@When("I search for {string}")
	public void i_search_for(String string) throws Exception {
		ebayhome_actions.enterSearchString(string);
		ebayhome_actions.clickSearchBtn();
		Thread.sleep(1000);
	}

	@Then("I validate atleast {int} search items are present")
	public void i_validate_atleast_search_items_are_present(Integer expcount) {
		int itemCountInt = ebayhome_actions.getSearchItemsCount();
		if(itemCountInt < expcount) {
			fail("Search results are less than expected count");
		}
	}
	@When("I search for {string} in {string} category")
	public void i_search_for_in_category(String string, String string2) throws Exception {
		ebayhome_actions.enterSearchString(string);
		ebayhome_actions.selectCategory(string2);
		ebayhome_actions.clickSearchBtn();
		Thread.sleep(1000);
	}
	
	@When("I click on {string}")
	public void i_click_on(String string) throws Exception {
		ebayhome_actions.clickonbreadcrumblink(string);
		Thread.sleep(1000);
	}

	@Then("I validate that page navigates to {string} and title contains {string}")
	public void i_validate_that_page_navigates_to_and_title_contains(String url, String title) {
		
		String actUrl = common_actions.getCurrentPageUrl();
		String actTitle = common_actions.getCurrentPageTitle();
		if(!actUrl.equals(url)) {
			fail("Page does not navigate to expected url " + url);
		}
		if(!actTitle.contains(title)) {
			fail("Page title mismatch " + title);
		}
	}

}
